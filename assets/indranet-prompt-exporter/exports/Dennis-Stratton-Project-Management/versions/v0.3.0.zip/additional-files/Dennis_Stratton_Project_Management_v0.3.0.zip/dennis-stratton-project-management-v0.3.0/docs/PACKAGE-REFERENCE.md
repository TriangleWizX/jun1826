# Package reference

This page defines the assembled v0.3.0 release topology and the maintained receipts used to verify it.

## Assembled release root

```text
release-v0.3.0/
|-- .agents/
|   |-- plugins/
|       |-- marketplace.json
|-- plugins/
|   |-- dennis-stratton-project-management/
|       |-- .codex-plugin/plugin.json
|       |-- skills/dennis-stratton-project-management/...
|-- codex/
|   |-- dennis-stratton-project-management/
|   |   |-- SKILL.md
|   |-- dennis-stratton-project-management-v0.3.0-codex-plugin.zip
|-- claude/
|   |-- dennis-stratton-project-management-v0.3.0.zip
|       |-- dennis-stratton-project-management/
|           |-- SKILL.md
|-- docs/...
|-- START-HERE.md
|-- HOST-COMPATIBILITY.md
|-- PROVENANCE.md
|-- RELEASE-NOTES.md
|-- LICENSE.md
|-- NOTICE.md
|-- TERMS-OF-USE.md
|-- THIRD-PARTY-NOTICES.md
|-- DATA-AND-PRIVACY.md
|-- SECURITY.md
|-- SUPPORT.md
```

## Maintained package receipts

Use these files instead of archive hashes copied into prose:

- [release manifest](../RELEASE-MANIFEST.json): complete release-tree inventory, component identity, size, member count, and hashes;
- [component checksum index](../COMPONENT-SHA256SUMS.txt): Codex and Claude archive checksums;
- [product package manifest](../../package-manifest.json): Codex, Claude, and complete-distribution package records; and
- [distribution checksum index](../../dist/SHA256SUMS.txt): checksums for all three distributed archives.

Any change to runtime or the release tree invalidates earlier package receipts. Regenerate the release and rerun all 26 package-verification checks before distributing the changed candidate. A package receipt is a byte snapshot only: it never establishes current repository existence, owner, visibility, branch, HEAD, worktree state, synchronization, tag, release, or remote custody. Those claims require a separate fresh observation of the intended repository and ref.

## Artifact roles

### Repo marketplace

`.agents/plugins/marketplace.json` exposes the local Codex plugin source. Its plugin `source.path` must be relative to the marketplace root and begin with `./`.

### Codex plugin directory

`plugins/dennis-stratton-project-management` is the installed local-plugin source. It contains the plugin manifest and one primary skill.

### Standalone Codex skill

`codex/dennis-stratton-project-management` contains `SKILL.md` directly and all files the skill references. Copy the complete directory into one `.agents/skills` discovery root.

### Codex plugin archive

`codex/dennis-stratton-project-management-v0.3.0-codex-plugin.zip` is the packaged Codex plugin. It must preserve the plugin directory structure, including `.codex-plugin/plugin.json` and `skills/`.

### Claude custom-skill archive

`claude/dennis-stratton-project-management-v0.3.0.zip` must contain exactly one top-level `dennis-stratton-project-management` folder. That folder contains `SKILL.md` directly. Files must not be placed directly at ZIP root, and an extra release wrapper must not surround the skill folder.

## Runtime contents

The primary skill contains:

- `SKILL.md`;
- `agents/openai.yaml` for Codex presentation metadata;
- `assets/` decision-oriented authorization, gate, forecast/capacity, stakeholder/adoption, recovery, closeout, transition, and starter-record templates;
- `knowledge/` operating doctrine for authorization/benefits, governance/forecast/capacity, stakeholder/adoption/commercial alignment, control, status, framework fit, and recovery;
- `references/canonical/` supplied source custody;
- `schemas/project-control.schema.json` for v2 and `schemas/project-control-v1.schema.json` for migration provenance;
- `scripts/project_control.py`;
- `tests/`;
- `evals/`;
- `examples/` for phase/milestone recovery and authorization/steering;
- `fallbacks/`; and
- `manifest.json`.

The package contains no MCP server, connector, credential, network dependency, telemetry client, third-party Python dependency, or pre-populated user record estate. The optional CLI creates and maintains the centralized estate when authorized. Resolve it by explicit `--store`, `DENNIS_PROJECT_HOME`, or `~/.dennis-stratton/project-records`, always outside replaceable package, install, release, cache, temporary, upload, and global skill-root locations.

## Verify a package before installation

Goal: confirm topology and identity without changing a host.

Prerequisites: the assembled release root, an archive viewer or PowerShell, and the maintained release or distribution receipt that applies to the artifact.

1. Confirm the expected artifact exists.
   - Expected result: its exact versioned name is present.
   - If different: stop; do not substitute a development directory.
2. Inspect directory or ZIP topology.
   - Expected result: entrypoints are at the locations defined on this page.
   - If different: reject the package for reassembly.
3. Compare the artifact hash to the applicable maintained manifest or checksum index.
   - Expected result: hashes match.
   - If different: quarantine the artifact and preserve both values.
4. Confirm the package identifies `dennis-stratton-project-management` version `0.3.0`.
   - Expected result: plugin and runtime identities agree.
   - If different: reject the package.

Safe stopping state: no host files have changed and the suspect artifact remains available for investigation.

Recovery path: obtain a freshly assembled authorized artifact and its final hash receipt. Do not rename or restructure the suspect archive as a substitute for controlled reassembly.

Completion proof: artifact name, topology, identity, and hash all match the applicable maintained receipt.

## Current state

Current deterministic package results are recorded in the versioned verification receipt after final assembly. The gate covers required surfaces, canonical parity, safe archive roots and extraction, strict JSON and text hygiene, receipt consistency, official validators, extracted tests, and maintained example validation.

A separate packaged estate lifecycle check exercises both routes. In a bounded temporary estate, read-only lookup creates no state; authorized ensure creates one canonical record and records directory; lookup recovers it after runtime replacement; repeated ensure is idempotent; and its fingerprint remains stable. This does not establish live-host invocation, user comprehension, concurrency, backup quality, or field durability.

This is current v0.3.0 candidate package evidence, not live-host or repository evidence. Installation, discovery, activation, explicit invocation, implicit selection, operational health, remote custody, public distribution, project outcomes, and field value remain separate. A correct-looking response without a host-native skill-use signal does not confirm invocation or health.
