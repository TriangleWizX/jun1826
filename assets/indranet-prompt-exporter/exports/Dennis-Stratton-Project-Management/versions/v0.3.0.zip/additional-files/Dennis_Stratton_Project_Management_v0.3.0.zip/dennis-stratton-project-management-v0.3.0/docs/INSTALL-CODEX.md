# Install for Codex

Version 0.3.0 provides an assembled local Codex plugin, a versioned plugin archive, and a standalone Codex filesystem skill. The candidate is accepted only after the current package receipt passes. Live installation has not been tested.

Build-time official OpenAI sources observed on 2026-08-20: [Build skills](https://learn.chatgpt.com/docs/build-skills) and [Build plugins](https://learn.chatgpt.com/docs/build-plugins), verified 2026-08-20.

## Choose the route

Use the local plugin for the packaged, shareable Codex experience in the ChatGPT desktop app and Codex CLI plugin browser. Use the standalone skill for repository or personal filesystem discovery, including the Codex IDE extension.

Do not install both routes into the same test scope. Duplicate skill names can appear separately rather than merge.

If you use the optional CLI, resolve its script separately from the centralized record estate. Set `DENNIS_PROJECT_HOME` for an environment-managed estate, pass `--store` for an explicit estate, or accept the user-scoped default `~/.dennis-stratton/project-records`. Do not place that estate under a plugin directory, `.agents/skills`, release tree, package extraction directory, cache, or temporary location. On project entry, Dennis locates the project record there before substantial work and creates it only when durable project work is authorized.

## Install the local Codex plugin

Goal: add the private release root as a local marketplace, install the plugin, and test discovery in one named Codex host.

Prerequisites:

- the authorized v0.3.0 candidate private release root and its successful package receipt;
- `.agents/plugins/marketplace.json` in that root;
- `plugins/dennis-stratton-project-management/.codex-plugin/plugin.json`;
- permission to install a local plugin;
- Codex CLI available for marketplace registration; and
- the ChatGPT desktop app available for local plugin installation and testing.

1. Open PowerShell at the assembled `release-v0.3.0` directory and confirm both paths exist:

   ```powershell
   Test-Path .agents/plugins/marketplace.json
   Test-Path plugins/dennis-stratton-project-management/.codex-plugin/plugin.json
   ```

   - Expected result: both commands return `True`.
   - If different: stop. The release is incomplete or you opened the wrong directory.
2. Add the release root as a local marketplace:

   ```powershell
   codex plugin marketplace add .
   codex plugin marketplace list
   ```

   - Expected result: the list includes a marketplace whose resolved root is the current release directory.
   - If different: preserve the exact command output and verify the marketplace file.
3. Restart the ChatGPT desktop app.
   - Expected result: the local marketplace becomes available as a source in the Plugins Directory.
   - If different: confirm you restarted the app, not only the conversation.
4. Open the Plugins Directory, choose the local marketplace source, and install `Dennis Stratton Project Management`.
   - Expected result: the app reports the plugin installed and exposes its bundled skill.
   - If different: do not add a second marketplace. Save the exact UI text and follow recovery.
5. Confirm discovery in the host's skills inventory or selector.
   - Expected result: Dennis appears once.
   - If different: record discovery failure and stop before supplying project data.
6. In a new conversation, use the host-native skill selector to select Dennis explicitly.
   - Expected result: a selected-skill indicator, attachment, or inspectable skill-use trace identifies Dennis for the request.
   - If different: record `explicit invocation attempted; invocation unconfirmed`. Merely typing `$dennis-stratton-project-management` or the skill name without a native selection result is not invocation proof.
7. In a second new conversation, make a matching request without naming Dennis.
   - Expected result: a host-native trace identifies implicit Dennis selection.
   - If the host exposes no such signal: record `implicit selection unconfirmed`; do not infer selection from the wording of the answer.
8. Run the representative acceptance prompt after confirmed invocation.
   - Expected result: purpose, hierarchy, authority, evidence, and completion boundaries remain distinct.
   - If invocation is unconfirmed but the answer passes: record `behavioral observation passed; invocation unconfirmed; skill health unconfirmed`.

Safe stopping state: the marketplace may remain registered, but the plugin is disabled or uninstalled and no private project data has been supplied.

Recovery path: use `codex plugin marketplace list` to identify the registered source. Remove it with `codex plugin marketplace remove <marketplace-name>` only if you intend to remove that source. Restart the desktop app. Preserve the package and evidence before deleting anything.

Completion proof: marketplace registration, plugin installation, discovery, explicit invocation, implicit selection, and healthy behavior each have separate evidence. Native invocation evidence is required before calling the skill healthy.

## Install the standalone Codex skill

Goal: copy the standalone skill into one Codex discovery root and prove it appears once.

Prerequisites:

- the v0.3.0 candidate `codex/dennis-stratton-project-management` directory and its successful package receipt;
- permission to write the chosen discovery root; and
- no existing skill with the same name in the test scope.

Choose one destination:

- personal scope: `$HOME/.agents/skills/dennis-stratton-project-management`;
- repository scope: `$REPO_ROOT/.agents/skills/dennis-stratton-project-management`.

1. Confirm the package entrypoint exists:

   ```powershell
   Test-Path codex/dennis-stratton-project-management/SKILL.md
   ```

   - Expected result: `True`.
   - If different: stop; do not copy an incomplete package.
2. Confirm the destination does not already exist.
   - Expected result: the destination is absent.
   - If different: stop and decide whether you are updating or removing the existing installation.
3. Copy the complete `dennis-stratton-project-management` folder to the chosen `.agents/skills` directory.
   - Expected result: `SKILL.md` and all referenced resources exist under one destination folder.
   - If different: remove only the incomplete destination after verifying its resolved path.
4. Start or restart Codex. Open a working directory inside the intended repository scope when testing a repo skill.
   - Expected result: the skills list includes Dennis once.
   - If different: confirm the destination scope and restart Codex.
5. Repeat the explicit invocation, implicit selection, and healthy-behavior cases from the plugin procedure.
   - Expected result: each case has a separate host-native signal and result.
   - If no native invocation signal is available: invocation and health remain unconfirmed even when the response looks correct.

Safe stopping state: the copied folder remains disabled by removal from the discovery root or by host configuration, and the original package remains unchanged. Canonical project records remain outside both paths.

Completion proof: the exact destination, v0.3.0 candidate package receipt, discovery result, explicit invocation, implicit selection, and behavioral result are recorded separately.