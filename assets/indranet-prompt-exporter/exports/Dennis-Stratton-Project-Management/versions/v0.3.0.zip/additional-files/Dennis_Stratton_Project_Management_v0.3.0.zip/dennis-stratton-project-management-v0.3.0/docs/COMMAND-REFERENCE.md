# Command reference

`project_control.py` uses Python 3.10+ standard library only. Run it from an authorized unpacked or installed skill. Store-aware commands resolve explicit `--store`, `DENNIS_PROJECT_HOME`, then `~/.dennis-stratton/project-records`.

## Exit codes

- `0`: operation succeeded; `locate` may report `found: false`.
- `1`: file, JSON, identity, ambiguity, migration, overwrite, adoption, or operational failure.
- `2`: argument usage failure, or a parsed record is structurally invalid for `validate` or `status`.

## store-path

```text
project_control.py store-path [--store PATH]
```

Resolves the centralized estate without creating it. Returns the path, resolution source, environment-variable name, and existence state.

## locate

```text
project_control.py locate [--store PATH] [--project-id ID] [--project-name NAME] [--source-locator LOCATOR]
```

Requires at least one selector. Multiple selectors are conjunctive. Returns one exact match or `found: false` without creating state. Ambiguous matches fail closed.

## ensure

```text
project_control.py ensure [--store PATH] --project-name NAME --owner OWNER --outcome OUTCOME [--project-id ID] [--source-locator LOCATOR]
```

Returns the unique existing project or creates one estate directory, v2 control record, and linked-record directory. It is idempotent for a matching identity and refuses conflicting IDs, names, locators, invalid existing records, and occupied unregistered paths.

## adopt

```text
project_control.py adopt V2_RECORD [--store PATH]
```

Copies a valid external v2 record into the estate without modifying its source. Equal same-ID content returns the existing canonical record. Different same-ID content fails. Migrate v1 first.

## list-projects

```text
project_control.py list-projects [--store PATH]
```

Lists canonical project controls and diagnostics for unreadable or malformed entries. It does not validate project truth or choose among duplicates.

## bootstrap

```text
project_control.py bootstrap OUTPUT --project-name NAME --owner OWNER --outcome OUTCOME [--project-id ID] [--source-locator LOCATOR] [--force]
```

Creates a provisional v2 record at an explicit path. Normal project entry should use `ensure`; use `bootstrap` only for controlled external workflows.

## migrate

```text
project_control.py migrate V1_RECORD V2_OUTPUT [--force]
```

Creates a separate v2 derivative and never modifies the input. New v2 fields remain conservative reassessment prompts.

## validate, status, and fingerprint

```text
project_control.py validate RECORD [--json]
project_control.py status RECORD [--output PATH] [--force]
project_control.py fingerprint RECORD [--json]
```

`validate` checks schema, references, declared completion invariants, timestamps, forecast order, and WIP exceptions. `status` renders a project-scale Markdown view. `fingerprint` hashes canonical JSON key ordering.

## Safety boundary

Inspect identity conflicts before changing anything. Preserve before-and-after fingerprints for consequential replacements. A successful command proves the declared local operation, not authentic authority, evidence truth, delivery, acceptance, health, or value.
