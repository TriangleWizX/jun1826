# Recovery, support, update, and removal

Start from the observable symptom. Preserve evidence before resetting anything.

## The host does not list or load Dennis

1. Confirm the package entrypoint and intended host scope.
2. Check overlapping discovery roots for duplicate Dennis names.
3. Restart the host after filesystem or marketplace changes.
4. Test explicit invocation with a host-native selector or inspectable trace.
5. Test implicit selection separately, without naming Dennis.
6. Test healthy behavior only after invocation is confirmed.

If native evidence is absent, record `invocation unconfirmed`; a Dennis-like answer is not proof. Safe stopping state: disable the skill and withhold project data. Completion proof: discovery, explicit invocation, implicit selection, and healthy behavior have separate results.

## The estate lookup fails

Resolve the estate in this order: explicit `--store`, `DENNIS_PROJECT_HOME`, then `~/.dennis-stratton/project-records`.

- If `locate` reports no match, do not create state for read-only work. For authorized durable work, use `ensure` with stable identity and authority fields.
- If lookup is ambiguous, stop mutation and resolve duplicate identity from controlling sources.
- If diagnostics identify malformed entries, preserve their bytes and repair or quarantine them with project authority.
- If a record exists outside the estate, validate it. Use `adopt` only for a valid v2 record; preserve the source. Migrate v1 to a separate v2 record before adoption.
- Never use `--force` or manual copying to conceal a conflict.

Completion proof: one unique canonical record is locatable in the estate, validates, and points to the intended project identity.

## The CLI says INVALID

Prerequisites: the original canonical estate record, full validation output, and independently resolved runtime path.

1. Make a recoverable copy under the same project's `records/` directory or another authorized backup system.
2. Use the first diagnostic code and JSON path to bound the defect.
3. Correct only source-backed values.
4. Rerun `validate`, `status`, and `fingerprint`.

Do not bootstrap or ensure over invalid data. Exit `2` after successful JSON-object parsing means record validation failed; argparse usage also exits `2` but writes usage to standard error. File, JSON, identity, and operational failures exit `1`.

Completion proof: the repaired record validates, status agrees with governing sources, and before-and-after fingerprints are preserved.

## Status is valid but wrong

Structural validity does not make a declaration true. Stop consequential mutation, gather controlling sources and evidence, reconcile purpose, hierarchy, authority, completion, and next action, then update only with authorization. Validate and render again.

Safe stopping state: disputed claims are unknown or conflicted and no consequential action depends on them. Completion proof: the accountable authority accepts the correction.

## Update Dennis

Prerequisites: an authorized replacement package, its receipts and release notes, the current installed scope, and a separately resolved estate.

1. Resolve the estate and list its projects before changing the runtime.
2. Preserve the current package receipt and project fingerprints.
3. If the estate is inside a package, install, cache, temporary, or upload path, stop and relocate it before update.
4. Disable one installation scope, replace it, and rerun discovery, invocation, behavior, estate lookup, validation, and fingerprint checks.
5. Remove the old package only after the replacement is healthy or rollback is chosen.

For v1 data, preserve the original, create a separate v2 derivative with `migrate`, validate it, then use `adopt`. No later schema migration is established by this release.

Completion proof: the new version appears once, the prior estate remains readable, unique records are recovered, and rollback material remains available.

## Remove Dennis

Resolve and verify the exact installed target before removal. The centralized estate is a separate asset and must not be inside that target.

- Standalone Codex: remove only the resolved Dennis directory from the chosen discovery root, then restart and verify absence.
- Codex plugin: uninstall or disable Dennis. Remove a marketplace only if no other plugin needs it.
- Claude: disable or delete the named custom skill through `Customize > Skills`.

If project state is found in the removal target, stop. Adopt a valid v2 record into the authorized estate or migrate v1 first, verify the estate copy, then remove only the obsolete duplicate with explicit authority.

Safe stopping state: Dennis cannot be invoked, the estate remains intact, and an authorized release package is retained only when policy permits. Completion proof: the host no longer lists Dennis and no estate record was deleted.

## Request support

Use the private channel in [Support](../SUPPORT.md). Include the version, host and scope, redacted command or UI output, estate resolution source, diagnostic code, and the smallest reproducible example. Never send credentials or unredacted project records in the first report.