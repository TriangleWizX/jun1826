# Host compatibility

This matrix describes v0.3.0 candidate package fit and evidence available on 2026-08-20. It is not a live compatibility certification. Final package evidence is recorded in the release receipts after assembly; live-host evidence remains separate.

| Host path | Intended artifact | Package structure | Current evidence | Unestablished boundary |
|---|---|---|---|---|
| Codex local plugin | `plugins/dennis-stratton-project-management` and `codex/dennis-stratton-project-management-v0.3.0-codex-plugin.zip` | Plugin manifest at `.codex-plugin/plugin.json` with one skill under `skills/` | The v0.3.0 package is subject to exact-parity, safe-extraction, validator, and extracted-test gates | Marketplace install; discovery; activation; explicit invocation; implicit selection; health |
| Codex standalone skill | `codex/dennis-stratton-project-management` | `SKILL.md` directly in the skill directory with supporting resources | The v0.3.0 package is subject to exact canonical-parity and extracted-test gates | Repo or user installation; discovery; activation; explicit invocation; implicit selection; health |
| Claude custom skill | `claude/dennis-stratton-project-management-v0.3.0.zip` | One top-level `dennis-stratton-project-management` folder with `SKILL.md` directly inside it | The v0.3.0 package is subject to installable-root, exact-parity, validator, and extracted-test gates | Upload; enablement; discovery; activation; explicit invocation; implicit selection; health |
| Optional CLI | Separately resolved `scripts/project_control.py` | Python 3.10 or newer, standard library only | Canonical v0.3.0 evidence includes 40 passing tests and 23 passing runtime structural checks; packaged-route evidence is recorded after assembly | Execution in a live installed host and behavior on customer records |

The maintained v0.3.0 eval contract contains 24 cases across 18 indispensable dimensions, including centralized record-estate entry, creation, read-only handling, and conflict refusal. Forward-test evidence is reported separately from full-suite, host-invocation, and field-health claims.

Use the [release manifest](RELEASE-MANIFEST.json) and [component checksum index](COMPONENT-SHA256SUMS.txt) for release-component identity. From the product root, use the [package manifest](../package-manifest.json) and [distribution checksum index](../dist/SHA256SUMS.txt) for all packaged artifacts. The maintained receipts identify the v0.3.0 package bytes; do not duplicate mutable hashes in prose.

Package evidence never establishes current repository existence, owner, visibility, branch, HEAD, worktree state, synchronization, tag, release, or remote custody. Any current repository claim requires a separate fresh observation of the intended repository and ref.

## Codex support boundary

Official OpenAI documentation observed on 2026-08-20 stated that standalone skills are available in the ChatGPT desktop app, Codex CLI, and IDE extension. Codex reads repository skills from `.agents/skills` and user skills from `$HOME/.agents/skills`. Plugins work in Chat and Work across ChatGPT web, desktop, and mobile, in Codex in the ChatGPT desktop app, and through the Codex CLI plugin browser; they are not available in the IDE extension.

Source: [OpenAI Build skills](https://learn.chatgpt.com/docs/build-skills) and [OpenAI Build plugins](https://learn.chatgpt.com/docs/build-plugins), verified 2026-08-20.

These are host documentation facts, not Dennis live-test results.

## Claude support boundary

Official Anthropic support observed on 2026-08-20 stated that custom skills can be uploaded as ZIP files through `Customize > Skills` when the required Skills and code-execution capabilities are enabled. The ZIP should contain the skill folder as its root. The custom skill can then be enabled in the skills list.

Source: [Use skills in Claude](https://support.claude.com/en/articles/12512180-use-skills-in-claude) and [How to create custom skills](https://support.claude.com/en/articles/12512198-how-to-create-custom-skills), verified 2026-08-20.

These are host documentation facts, not a successful Dennis upload.

## Runtime and record boundary

The conversational workflow depends on host skill support. The deterministic CLI depends on Python 3.10 or newer. The runtime manifest declares no network or credential dependencies.

Resolve the CLI script from an authorized installed or separately unpacked runtime. Resolve the one centralized record estate in this order: explicit `--store`, `DENNIS_PROJECT_HOME`, then `~/.dennis-stratton/project-records`. Dennis-created canonical records live under `<estate>/projects/<project-key>/project-control.json`, with related project-management artifacts under the adjacent `records/` directory. Never put the estate inside a replaceable package, install, release, cache, temporary, or upload path.

A host-managed skill may expose no addressable script path. In that case, use conversational guidance or export complete JSON to project custody, then mark CLI validation `not run` until a separately resolved runtime checks it. A chat response, preview, download, or attachment is not canonical by itself.

Host access, model behavior, filesystem permissions, code execution, organization policy, and data handling remain separate host boundaries.

## Compatibility proof procedure

Prerequisites: install one verified v0.3.0 package in one named host and scope, with a non-sensitive acceptance case ready.

1. Confirm the host lists Dennis Stratton Project Management.
   - Expected result: the exact skill or plugin name appears once.
   - If different: remove duplicate copies and restart the host.
2. Test explicit invocation in a new conversation using the host-native selector or attachment control when exposed.
   - Expected result: a selected-skill indicator, attachment, or inspectable trace identifies Dennis.
   - If different: record `explicit invocation attempted; invocation unconfirmed`. A typed name or Dennis-like answer is not invocation proof.
3. Test implicit selection in another new conversation without naming Dennis.
   - Expected result: a host-native trace identifies Dennis selection for the matching request.
   - If no native signal exists: record `implicit selection unconfirmed`.
4. Run a representative status or recovery case after invocation is confirmed.
   - Expected result: purpose, hierarchy, authority, evidence, and completion remain distinct.
   - If different: disable the package and preserve the response for review.
   - If behavior passes but invocation is unconfirmed: record `behavioral observation passed; invocation unconfirmed; skill health unconfirmed`.

Safe stopping state: the skill is disabled, project data remains in its original custody, and the failed prompt, response, and native invocation signal or absence are saved.

Completion proof: one named host has package, installation, discovery, explicit invocation, implicit selection, and healthy behavior recorded as separate evidence cases.