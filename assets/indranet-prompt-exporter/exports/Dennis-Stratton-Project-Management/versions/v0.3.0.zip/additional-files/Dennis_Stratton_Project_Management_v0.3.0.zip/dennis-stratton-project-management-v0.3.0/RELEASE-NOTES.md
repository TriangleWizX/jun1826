# Dennis Stratton Project Management v0.3.0 release notes

Status: private release candidate. Not publicly released.

## What changed

Version 0.3.0 adds one centralized, user-scoped project-record estate and requires Dennis to check it whenever he enters an identifiable project.

Store resolution is deterministic:

1. explicit `--store`;
2. `DENNIS_PROJECT_HOME`;
3. `~/.dennis-stratton/project-records`.

The normal project layout is `projects/<stable-project-key>/project-control.json` plus a sibling `records/` directory for Dennis-created project-management artifacts.

The CLI adds `store-path`, `locate`, `ensure`, `adopt`, and `list-projects`.

## Project-entry behavior

Dennis now resolves and checks the estate before substantial project work. He matches by project ID, exact name, and authoritative source locator rather than fuzzy similarity. A unique record is loaded, validated, and reconciled with current evidence.

When no record exists, authorized durable project work includes creating its required canonical entry. A strictly read-only request checks the store but creates nothing. Ambiguous matches, malformed records, identity conflicts, and same-ID content conflicts stop mutation.

## Existing records

Version 0.3.0 does not move or delete existing project files automatically. To centralize an authoritative external v2 record, confirm owner authority and run `adopt`. For v1, migrate to a separate v2 derivative first and adopt the derivative. The source remains unchanged.

After adoption, designate the estate copy as canonical for future Dennis-managed updates. Preserve or mark the legacy copy according to its own custody rules.

## Compatibility

The `cd-project-control/v2` schema remains unchanged. Existing v2 records remain valid. The conversational skill needs a host that loads Agent Skills-style Markdown and resources. The CLI remains Python 3.10+ standard-library only with no network or credential dependency.

## Known limits

- The CLI validates declared structure and local store behavior, not real-world truth.
- Multi-process concurrent writers are not proven.
- No remote synchronization, encryption, access-control service, or third-party PMIS adapter is included.
- Live host behavior must be verified for each target host.
- The product does not authorize consequential external action or guarantee outcomes.
- No formal accessibility-conformance claim is made.

## Distribution

This remains private proprietary material. Private repository synchronization does not create a public release, GitHub Release, tag, marketplace submission, website publication, announcement, Discord upload, or permission to redistribute.
