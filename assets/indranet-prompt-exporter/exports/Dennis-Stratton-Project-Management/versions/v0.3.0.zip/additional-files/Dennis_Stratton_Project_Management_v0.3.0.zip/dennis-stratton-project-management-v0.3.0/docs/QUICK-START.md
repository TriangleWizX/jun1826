# Quick start

Use this path whenever Dennis enters an identifiable project.

## Recover continuity first

Prerequisites: Dennis is available, you may access the project material, and you know a project ID, exact name, or authoritative source locator.

1. Resolve the record estate.

   ```powershell
   python <skill-root>/scripts/project_control.py store-path
   ```

   Expected result: JSON identifies the owner-approved explicit store, `DENNIS_PROJECT_HOME`, or the user-scoped default. This creates nothing.

2. Locate the project.

   ```powershell
   python <skill-root>/scripts/project_control.py locate --project-id <id>
   ```

   Expected result: one unique match or `found: false`. If multiple records compete, stop mutation and obtain an owner decision.

3. If a record exists, validate and reconcile it with current project sources.

   ```powershell
   python <skill-root>/scripts/project_control.py validate <returned-project-control.json>
   ```

   Expected result: structural diagnostics are explicit. A valid but stale record still requires reconciliation.

4. Ask Dennis:

   > Orient this project from its canonical record and current sources. State whether the active unit is done, whether the project remains justified, the exact location, current outcome and evidence, forecast confidence, bottleneck, next decision, and next owned move.

Completion proof: the answer names the canonical record path and distinguishes stored claims from fresher evidence.

## Create when durable work is authorized

If `locate` returns `found: false` and the request authorizes starting, planning, executing, steering, recovering, or closing the project with durable records:

```powershell
python <skill-root>/scripts/project_control.py ensure --project-id <id> --project-name "<name>" --owner "<owner>" --outcome "<outcome>" --source-locator "<authority>"
```

Expected result: one project directory contains `project-control.json` and `records/`. Use the returned paths for future Dennis-managed state.

A strictly read-only request does not run `ensure`. Report the missing canonical record and continue only with a bounded review of supplied evidence.

## When the host cannot address the CLI

1. Ask Dennis to state the proposed store path and project identity.
2. Ask for the complete `cd-project-control/v2` JSON as a draft.
3. Save it only in the owner-approved estate when write authority exists.
4. Mark `store lookup not run`, `unique match not proven`, and `validation not run`.
5. When an addressable runtime becomes available, use `adopt`, `validate`, and `fingerprint`.

Recovery: if export is truncated or malformed, preserve it as a failed transport copy. Do not fill missing project truth from guesswork.

Completion proof: one canonical estate location and one project identity are preserved for re-entry, with every unrun guarantee named.
