# Rights and governance

Dennis Stratton Project Management v0.3.0 is private, proprietary Collaborative Dynamics material.

## Rights

Possession does not grant permission to:

- use beyond written authorization;
- copy or modify;
- distribute, publish, sublicense, sell, or host;
- create derivative works;
- make the package available to a public marketplace or directory; or
- disclose canonical sources or private project evidence.

See [License](../LICENSE.md) and [Terms of use](../TERMS-OF-USE.md).

Third-party names, marks, standards, formats, documentation, and software remain the property of their owners. Reference does not imply endorsement, partnership, certification, or formal conformance. See [Third-party notices](../THIRD-PARTY-NOTICES.md).

## Product authority

Collaborative Dynamics retains product architecture, source custody, package, release, and distribution authority. The user or organization operating Dennis retains authority for its own project purpose, decisions, people, systems, records, and external effects. Dennis-managed project records remain in the operator-authorized centralized estate outside replaceable package and install paths. Product update or removal must not take custody of or delete that estate. Project authorities retain control of access, retention, backup, handoff, and external systems of record.

Dennis may recommend, structure, inspect, validate, and report within granted scope. It may not transform a recommendation into owner authorization.

## Distribution state

As of the v0.3.0 evidence cutoff:

- the product is private;
- initial private packages are assembled and locally verified;
- no public release exists;
- no universal plugin-directory or marketplace submission exists;
- no GitHub remote custody had been established at that cutoff;
- no open contribution channel exists; and
- no public redistribution is authorized.

A local marketplace file is an installation mechanism for an authorized private package. It is not public publication. Package receipts never establish current repository existence, owner, visibility, branch, HEAD, worktree state, synchronization, tag, release, or remote custody. Any current repository or distribution claim requires a separate fresh observation of the intended repository and ref.

## Change governance

Goal: change the product without losing source, evidence, or package truth.

Prerequisites:

- a scoped authorized change;
- identified source, runtime, documentation, verification, and release impacts;
- the current candidate fingerprint or manifest; and
- a rollback path.

1. Classify the change by affected authority and surfaces.
   - Expected result: source material, derivatives, runtime, documentation, and packages remain distinguishable.
   - If different: stop and reconstruct the change boundary.
2. Preserve supplied canonical sources byte for byte unless the source owner provides a replacement.
   - Expected result: source hashes remain stable or the replacement is explicitly registered.
   - If different: treat the candidate as untrusted.
3. Update derived runtime and documentation with named provenance.
   - Expected result: product behavior and customer claims remain aligned.
   - If different: narrow the claim or revert the derivative.
4. Re-run deterministic, behavioral, documentation, and package verification at the depth affected.
   - Expected result: each evidence class has a separate receipt.
   - If different: keep the candidate unreleased.
5. Obtain the relevant release and distribution approval.
   - Expected result: private custody and authorization are explicit.
   - If different: do not publish, submit, install broadly, or tag a release.

Safe stopping state: the previous frozen package remains recoverable, the changed candidate is clearly labeled, and no unauthorized distribution occurs.

Recovery path: revert the derivative candidate to the last authorized frozen state or retain it as an unreleased investigation branch. Never repair provenance by deleting the conflicting source or evidence.

Completion proof: source custody, candidate fingerprint, verification receipts, documentation manifest, package parity, approval, and destination state all agree.

## Feedback and support

Use the private channel in [Support](../SUPPORT.md). Do not send credentials, private project records, or proprietary sources in an initial report.