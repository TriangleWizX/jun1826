# Start here

Dennis Stratton Project Management v0.3.0 is a private project-governance Augment for consequential projects. It combines project-management judgment with a centralized local record estate and a deterministic `cd-project-control/v2` CLI.

## Choose your next task

- To install: use [Codex](docs/INSTALL-CODEX.md) or [Claude](docs/INSTALL-CLAUDE.md).
- To configure record custody: read [Project control](docs/PROJECT-CONTROL.md#choose-the-record-estate).
- To resume or start a project: use [Quick start](docs/QUICK-START.md).
- To look up exact commands: use [Command reference](docs/COMMAND-REFERENCE.md).
- To report or recover: use [Status and recovery](docs/STATUS-AND-RECOVERY.md).
- To update, remove, or troubleshoot: use [Recovery, support, update, and removal](docs/RECOVERY-SUPPORT-UPDATE-REMOVE.md).
- To inspect package contents: use [Package reference](docs/PACKAGE-REFERENCE.md).

## The continuity rule

For every identifiable project, Dennis checks one record estate before substantial project work. Resolution order is explicit `--store`, `DENNIS_PROJECT_HOME`, then `~/.dennis-stratton/project-records`.

A unique existing project record is loaded and reconciled. Authorized durable work with no record uses `ensure` to create one. Read-only work checks but does not create. Competing records stop mutation.

## Keep authority separate from tooling

A valid record does not prove the project is healthy, authorized, accepted, complete, or valuable. Dennis does not authorize spend, commit people, accept risk, contact stakeholders, change production, publish, sign, approve a baseline, or pause or cancel a project without relevant human authority.

## Safe first check

```powershell
python <skill-root>/scripts/project_control.py store-path
```

Expected result: JSON names the store path, the resolution source, and whether it exists.

Completion proof: you know the intended host path, the project-record estate, and the next reader task. If any is unclear, stop before installing or creating records.
