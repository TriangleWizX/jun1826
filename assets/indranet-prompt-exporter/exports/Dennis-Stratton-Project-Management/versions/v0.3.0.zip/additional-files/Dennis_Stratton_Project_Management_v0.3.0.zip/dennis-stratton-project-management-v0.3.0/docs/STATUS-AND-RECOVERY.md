# Status and recovery

## Enter the project record estate

Before reading status, resolve the centralized estate and locate the identifiable project. Load and validate the unique match. If no match exists and durable project work is authorized, create it with `ensure`; for read-only work, report the miss without creating state. Stop on ambiguity, identity conflict, or invalid canonical data.

## Read status at project scale

A useful status answers, in order:

1. Is the active completion unit done under its contract?
2. Does the project remain justified, and what benefit is at stake?
3. Where are we in the exact hierarchy?
4. What outcome exists, with what evidence?
5. What remains, and why?
6. What is the forecast range and confidence relative to baseline?
7. What capacity, queue, bottleneck, stakeholder, commercial, or gate condition governs the outcome?
8. What decision and owned move happen next?

Repository cleanliness, synchronized branches, deployed artifacts, accepted deliverables, operational readiness, and realized benefits are distinct states.

## Recover a confused or troubled project

Stop consequential mutation before building a new plan.

1. Preserve current records, source locators, decisions, dashboards, repository/runtime facts, and evidence.
   - Expected result: contradictory state remains inspectable.
2. Restore purpose, continued justification, source ranking, hierarchy, current location, completion contract, authority, and actual evidence.
   - Expected result: disputed claims are current, stale, superseded, unavailable, or conflicted rather than blended.
3. Triage immediate safety, compliance, financial, operational, or irreversible consequences.
   - Expected result: urgent containment is separated from project redesign.
4. Diagnose the control-system failure: authorization, scope, acceptance, integration, capacity, decision latency, incentives, vendor alignment, evidence, or another named mechanism.
5. Compare authorized options: recover, re-contract, pause, or cancel.
   - Evaluate remaining benefit, viability, cost, exposure, salvage value, displacement, dependencies, and authority. Sunk cost is not continued justification.
6. Record the decision, conditions, owners, baselines, residual exposure, and re-entry or termination condition.
7. Validate the record and render status before resuming.

Safe stopping state: the project is paused at a reversible boundary, disputed claims are marked, preserved evidence is locatable, and no consequential action depends on false certainty.

Completion proof: the accountable authority accepts the restored state and chosen disposition; the next move has an owner and evidence condition.

## Escalate an exception

Use `assets/governance-exception-record.md` when a tolerance is breached or a gate decision ages beyond its target. State the breach, consequence, evidence/confidence, decision authority, age, options, displacement, and required disposition. Escalation should improve a decision—not merely improve the color of a slide.
