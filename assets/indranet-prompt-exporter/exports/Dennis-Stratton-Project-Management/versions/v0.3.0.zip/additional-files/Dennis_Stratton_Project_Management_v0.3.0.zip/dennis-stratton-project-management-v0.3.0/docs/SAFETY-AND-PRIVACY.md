# Safety and privacy

Dennis often works near consequential plans, repository state, people, budgets, incidents, and organizational decisions. Treat that context as sensitive by default.

## Minimize project data

Goal: provide enough context for the next project decision without unnecessary disclosure.

Prerequisites:

- authority to use the source material;
- awareness of the host and model-provider data boundary; and
- a clear question or decision.

1. Identify the smallest source set that can answer the question.
   - Expected result: unrelated repositories, conversations, people, and documents stay out of scope.
   - If different: remove or redact them before continuing.
2. Remove credentials and secrets.
   - Expected result: no passwords, tokens, private keys, recovery codes, payment details, or authentication artifacts enter the host or control record.
   - If different: stop, rotate an exposed credential through its owning system, and preserve no copies in support material.
3. Redact personal, customer, financial, security, and proprietary details that do not change the decision.
   - Expected result: the task remains solvable with lower disclosure.
   - If different: document why the sensitive field is necessary and who authorized its use.
4. Keep all Dennis-managed project records in the one centralized record estate.
   - Expected result: the estate resolves by explicit `--store`, `DENNIS_PROJECT_HOME`, or the user-scoped default; it is outside replaceable runtime paths; backup, access, retention, and handoff follow project policy.
   - If different: stop. Adopt the valid record into the authorized estate, preserve the source, resolve any identity conflict, and retire or label derivatives.
5. Review output before external action.
   - Expected result: human authority remains responsible for decisions and effects.
   - If different: do not act.

Safe stopping state: project material remains in its original system, the skill is disabled if needed, and no external effect has occurred.

Recovery path: if sensitive data was disclosed, stop sharing, preserve only the minimum incident evidence, use the host or source-system controls to remove or restrict access when available, rotate exposed credentials, and contact the responsible security or privacy owner.

Completion proof: the retained context is necessary, authorized, redacted where possible, and stored only in the intended custody boundary.

## Record and runtime custody

The runtime and record estate are separate assets. Resolve the estate in this order: explicit `--store`, `DENNIS_PROJECT_HOME`, then `~/.dennis-stratton/project-records`. On every identifiable project entry, locate the project by stable ID, exact name, or source locator before substantial work. A missing lookup is read-only; `ensure` creates the estate, canonical `project-control.json`, and adjacent `records/` directory only when durable project work is authorized. Ambiguous, conflicting, or invalid matches stop mutation.

A bounded packaged lifecycle check exercises both host routes against temporary estates: lookup does not create state, authorized ensure creates centralized custody, the same record is recovered after runtime replacement, and repeated ensure is idempotent. This is packaged test evidence, not live-host, concurrency, backup, or field-durability evidence.

A chat response, JSON preview, download, or attachment is a draft or transport copy. A valid external v2 record becomes canonical only through explicit `adopt`, which preserves the source; v1 records require explicit migration to a separate v2 derivative first. If a host cannot reach the estate, label estate lookup and CLI validation `not run`.
## Runtime data behavior

The package declares no network or credential dependency. The optional CLI reads the record path you name and can write a new record or rendered status to a path you name. It does not independently transmit records.

The host, model provider, operating system, repository platform, and any connector or tool you separately enable have their own data flows and policies. Dennis cannot override them.

## Action safety

A plan, decision recommendation, validated JSON record, or `YES` status does not authorize:

- spending;
- hiring, assignment, or personnel action;
- external communication;
- publication or synchronization;
- production or infrastructure change;
- disclosure of private information;
- risk acceptance; or
- project cancellation.

Obtain the relevant human authority and use the system that owns the action.

## Accessibility claim

The documentation uses semantic Markdown structure and has a bounded automated and manual review. No browser, keyboard, screen-reader, representative-user, or formal conformance assessment has been completed. Do not claim formal accessibility conformance.