# Provenance

Dennis Stratton Project Management v0.3.0 is a private Collaborative Dynamics derivative built from supplied canonical project-management materials, dated official framework anchors, a private project-recovery incident, and maintained package code.

## Canonical supplied sources

The build preserves these files byte for byte in the product source custody area and in the skill's canonical references:

| Source | SHA-256 | Treatment |
|---|---|---|
| `Project Management Virtuoso - Dennis Stratton T3 v1.1.txt` | `35D438D41FFF4E63B38F0BB31A7E672C0C4E1F98C92108D05A9CA424B4F95EDE` | Preserved canonical source; the runtime persona is a named, product-safe derivative |
| `Project Management Virtuoso - Dennis Stratton - The Project-Management Judgment Engine - A Socio-Technical Systems Guide to Delivery Intelligence, Governance, and Project Recovery.md` | `45315E578A2A5C22C4F8BE0859C9C79BE382011D33F8AA367ADFE1340826E941` | Preserved canonical source; runtime doctrine is a named derivative |

The source register at the product root is the maintained machine-readable custody record.

## Private incident evidence

A private human-AI project incident supplied acceptance pressure for hierarchy custody, completion-state honesty, authority provenance, project-scale reporting, and correction-led recovery. The distributed teaching example is synthetic and anonymized. Its names, locators, evidence, and repository checkpoint do not describe a live project.

State: source-verified as a development input; not distributed as raw task history.

## Official framework anchors

The packaged framework-fit reference records a build-time snapshot observed on 2026-08-20 against official sources:

- [PMI PMBOK Guide](https://www.pmi.org/standards/pmbok);
- [PeopleCert PRINCE2 corporate framework](https://www.peoplecert.org/Organizations/Certifications/Prince2-Corporate-Framework);
- [GAO Agile Assessment Guide](https://www.gao.gov/products/gao-24-105506);
- [ISO 31000:2018](https://www.iso.org/standard/65694.html); and
- [NAO governance and decision-making on mega-projects](https://www.nao.org.uk/insights/governance-and-decision-making-on-mega-projects/).

These sources anchored edition or guidance facts at that build-time observation. The snapshot is not evidence that any official source was accessed in the current task. When currentness matters, reverify the linked authority; if access is unavailable, state that the package reports the value as of 2026-08-13 and that it was not reverified now. Dennis does not reproduce, certify, or formally implement those standards and frameworks.

## Host documentation anchors

Codex package guidance was checked against the official OpenAI manual snapshot dated 2026-08-20 and its [Build skills](https://learn.chatgpt.com/docs/build-skills) and [Build plugins](https://learn.chatgpt.com/docs/build-plugins) sources.

Claude custom-skill guidance was checked on 2026-08-20 against [Use skills in Claude](https://support.claude.com/en/articles/12512180-use-skills-in-claude) and [How to create custom skills](https://support.claude.com/en/articles/12512198-how-to-create-custom-skills).

Host procedures can change. Recheck them before release or after a host UI change.

## Verification provenance

Current v0.3.0 local evidence recorded on 2026-08-20 includes:

- 40 passing Python unit tests in canonical source;
- 23 of 23 runtime structural checks;
- 43 of 43 CLI contract checks;
- passing official skill and plugin validators;
- two structurally valid maintained examples;
- a maintained behavioral contract of 24 cases and 18 indispensable dimensions;
- a fresh independent forward test of estate entry, authorized creation and recovery, read-only non-creation, and conflict refusal;
- 26 deterministic package checks, including 40 tests and both examples from each extracted Codex and Claude route;
- a 9-output byte-for-byte reproducible rebuild; and
- a 2-of-2 packaged centralized-estate lifecycle check covering read-only lookup, authorized creation, recovery, idempotence, and runtime replacement.

The forward verdict is bounded to its isolated scenarios. Package and deterministic evidence does not establish live host invocation, field value, multi-process concurrency, backup quality, or user comprehension.
Use [the release manifest](RELEASE-MANIFEST.json), [the component checksum index](COMPONENT-SHA256SUMS.txt), [the product package manifest](../package-manifest.json), and [the distribution checksum index](../dist/SHA256SUMS.txt) for maintained package identity and hashes. Do not substitute hashes copied into prose.

This provenance does not establish Claude live installation, invocation, operational health, project outcomes, public publication, marketplace availability, or field value. Repository synchronization and local Codex installation require separate fresh observations of their exact targets.
