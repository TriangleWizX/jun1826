# Install for Claude

Version 0.3.0 ships as an assembled Claude custom-skill ZIP. The candidate is accepted only after the current package receipt passes. No Dennis upload, enablement, discovery, invocation, or live health test has been performed.

Build-time official Anthropic sources observed on 2026-08-20: [Use skills in Claude](https://support.claude.com/en/articles/12512180-use-skills-in-claude) and [How to create custom skills](https://support.claude.com/en/articles/12512198-how-to-create-custom-skills), verified 2026-08-20.

## Upload the custom skill

Goal: upload the authorized private ZIP, enable the skill, and test discovery, invocation, and behavior separately in a new Claude conversation.

Prerequisites:

- the v0.3.0 candidate `claude/dennis-stratton-project-management-v0.3.0.zip` and its successful package receipt;
- authorization to upload the private package to the intended Claude account or workspace;
- Skills enabled for the account;
- code execution and file creation enabled as required by the current host;
- for Team or Enterprise, any required owner-level organization settings; and
- no existing Dennis skill that would make the test ambiguous.

The ZIP must contain one top-level `dennis-stratton-project-management` folder with `SKILL.md` directly inside it. Do not upload an archive with files directly at the ZIP root or an extra release-wrapper folder.

1. Inspect the ZIP topology before upload.
   - Expected result: exactly one top-level skill folder contains `SKILL.md` and its supporting directories.
   - If different: stop and obtain a correctly assembled package.
2. In Claude, open `Customize > Skills`.
   - Expected result: the Skills page is available.
   - If different: check the account plan and organization settings; do not guess at a substitute upload surface.
3. Select the plus button, then `Create skill`, `Upload a skill`.
   - Expected result: Claude prompts for a ZIP file.
   - If labels have changed: use Anthropic's current official Skills guidance before proceeding.
4. Select `dennis-stratton-project-management-v0.3.0.zip` and complete the upload.
   - Expected result: Dennis Stratton Project Management appears once in the skills list.
   - If different: save the exact upload error and do not repeatedly rebuild or re-upload without inspecting the ZIP.
5. Enable the skill if it is not already enabled.
   - Expected result: the skill toggle indicates enabled.
   - If different: check account or organization policy.
6. Test explicit invocation in a new conversation. Use a host-native skill selector or attachment control to choose Dennis when Claude exposes one.
   - Expected result: a selected-skill indicator, attachment, or inspectable skill-use trace identifies Dennis for the request.
   - If the host exposes no native signal: record `explicit invocation attempted; invocation unconfirmed`. Naming Dennis in the prompt and receiving a plausible answer are not invocation proof.
7. Test implicit selection in another new conversation without naming Dennis.
   - Expected result: a host-native trace identifies Dennis selection for a matching project-status or recovery request.
   - If the host exposes no such trace: record `implicit selection unconfirmed`.
8. Test healthy behavior after invocation is confirmed.
   - Expected result: the response preserves project purpose, hierarchy, authority, evidence, and completion boundaries.
   - If behavior passes but invocation is unconfirmed: record `behavioral observation passed; invocation unconfirmed; skill health unconfirmed`.

Safe stopping state: the skill is disabled, no private project record has been supplied, and the original ZIP remains available for inspection.

Recovery path: disable the skill from `Customize > Skills`. To remove the uploaded custom skill, open its details, use the options menu next to the toggle, select `Delete`, and confirm. Re-upload only after the package or host issue is understood.

Completion proof: record the v0.3.0 candidate ZIP receipt, account or organization scope, upload result, enabled state, discovery result, explicit-invocation signal, implicit-selection signal, and behavioral result. Upload success alone is not invocation or health evidence.

## Durable records and the optional CLI

A host-managed Claude upload may not expose a stable, user-addressable filesystem path to the packaged `project_control.py`. Do not invent one and do not treat the upload sandbox as record custody.

Use Dennis conversationally, then ask it to resolve the centralized record estate: explicit `--store`, `DENNIS_PROJECT_HOME`, or `~/.dennis-stratton/project-records`. When the managed Claude surface cannot address that local estate, an exported `cd-project-control/v2` JSON remains a draft until an authorized local runtime adopts it into the estate. Keep the estate outside every package, install, cache, temporary, and upload path.

Mark estate lookup and CLI validation `not run` until a separately resolved authorized runtime performs them. If Claude cannot export a file or reach the estate, no durable canonical Dennis record was created; preserve needed state in the project's authorized system and state the persistence limit.

## Claude Code alternative

Claude Code supports filesystem skills under `~/.claude/skills/` for personal scope and `.claude/skills/` for project scope according to current official documentation. The v0.3.0 release is not currently specified as a dedicated Claude Code package, and this path has not been tested. Use the custom-skill ZIP route unless a separate Claude Code installation is explicitly evaluated. Even on a filesystem route, keep canonical project records outside the skill directory.