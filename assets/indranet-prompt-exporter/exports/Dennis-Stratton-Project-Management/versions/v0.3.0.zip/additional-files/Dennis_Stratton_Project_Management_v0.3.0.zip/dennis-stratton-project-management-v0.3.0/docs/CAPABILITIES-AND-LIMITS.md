# Capabilities and limits

Dennis Stratton Project Management v0.3.0 combines project-management judgment, a centralized local project-record estate, reusable decision records, and deterministic structural controls.

## Supported capabilities

Dennis can:

- resolve an explicit, environment-provided, or portable default record estate;
- locate a project by stable ID, exact name, or authoritative source locator without creating state;
- create one canonical project entry when durable work is authorized;
- preserve an external v2 source while adopting a canonical estate copy;
- stop on competing project identities or fingerprints;
- govern purpose, justification, benefits, authority, hierarchy, forecasts, capacity, stakeholders, commercial alignment, completion, change, recovery, transition, and benefit review;
- validate `cd-project-control/v2`, migrate v1 to a separate v2 derivative, render status, and fingerprint canonicalized content.

## Evidence boundaries

A resolved path does not prove the directory is authorized, protected, backed up, or reachable from every host. A located record does not prove it is valid, current, authoritative, or true. A valid record does not prove project health, delivery, acceptance, completion, or value. Adoption proves a local copy operation and source preservation in that execution; it does not confer owner authority or resolve dual-write governance.

Package validity, installation, discovery, invocation, health, documentation, private repository synchronization, and field value remain separate states.

## Not included

The package does not provide encryption, authentication, operating-system permissions, backups, secure deletion, remote synchronization, conflict-free concurrent editing, a database server, portfolio manager, live PMIS, or autonomous consequential authority.

It does not provide legal, financial, employment, compliance, safety, certification, or professional-licensure advice, and it does not guarantee schedule, cost, quality, acceptance, benefits, or outcomes.

## Known untested edges

Multi-process concurrent writes, hostile symlink or filesystem behavior beyond exercised package checks, network-home availability, very large estates, non-UTF-8 external records, full live Codex and Claude invocation behavior, representative-user testing, assistive-technology testing, third-party adapters, and realized customer outcomes require separate evidence.

No formal accessibility-conformance claim is made.

## Responsible stop

Stop mutation when project selectors are ambiguous, an existing record is invalid, a same-ID fingerprint conflicts, authority is missing, or the estate destination is not approved for the data. Preserve paths, fingerprints, diagnostics, and source files so the owner can decide the canonical next move.
