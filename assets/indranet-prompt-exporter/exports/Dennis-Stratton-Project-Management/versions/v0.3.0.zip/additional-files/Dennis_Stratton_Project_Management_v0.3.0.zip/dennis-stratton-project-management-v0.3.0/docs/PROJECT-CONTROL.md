# Centralized project control

Use the centralized record estate when project truth must survive conversations, handoffs, repositories, or recovery. Each project has one canonical `cd-project-control/v2` record. Status Markdown and dashboards are derived views.

## Choose the record estate

Resolution order:

1. explicit `--store <path>`;
2. `DENNIS_PROJECT_HOME`;
3. `~/.dennis-stratton/project-records`.

If your environment already provides a governed, always-reachable local data estate, set `DENNIS_PROJECT_HOME` to the Dennis project-record directory within it. Otherwise use the portable default.

Keep the estate outside packages, install directories, release trees, repositories, caches, temporary directories, upload sandboxes, and `.codex`.

```powershell
python <skill-root>/scripts/project_control.py store-path
```

Expected result: JSON reports `store`, `source`, and `exists` without creating state.

## Resume an existing project

```powershell
python <skill-root>/scripts/project_control.py locate --project-id <id>
python <skill-root>/scripts/project_control.py locate --project-name "<exact name>" --source-locator "<authority locator>"
```

Expected result: `found: true` returns one path and fingerprint. `found: false` creates nothing.

Load and validate the unique record, then reconcile it with current authoritative sources. Do not choose between competing records by file date or fuzzy name. If lookup is ambiguous, stop mutation and obtain an owner decision.

## Create the canonical entry

When no match exists and the requested work authorizes durable project creation or mutation:

```powershell
python <skill-root>/scripts/project_control.py ensure --project-id <id> --project-name "<name>" --owner "<owner>" --outcome "<observable world-change>" --source-locator "<authority>"
```

Expected result: `created: true` returns the new `project-control.json` and `records_directory`. A repeated call for the same identity returns `created: false` and the same record without overwriting it.

Replace template prompts only with source-backed state. Keep unknown forecasts, stakeholder positions, readiness, acceptance, and benefits unknown.

Store Dennis-created charters, authorization and benefits briefs, forecasts, stakeholder briefs, decisions, changes, gates, recovery checkpoints, closeouts, and benefits-transition records below `records_directory`. Reference external evidence in its original custody.

## Adopt an external record

Prerequisite: owner authority to centralize custody and a structurally valid v2 record.

```powershell
python <skill-root>/scripts/project_control.py adopt <external-v2.json>
```

Expected result: the source bytes remain unchanged and the estate copy is returned. Record both fingerprints and designate the estate copy as canonical for future Dennis-managed writes.

For v1:

```powershell
python <skill-root>/scripts/project_control.py migrate <v1.json> <v2.json>
python <skill-root>/scripts/project_control.py adopt <v2.json>
```

If adoption reports an identity or fingerprint conflict, stop. Preserve both records for owner resolution; do not force an overwrite.

## Validate after material change

```powershell
python <skill-root>/scripts/project_control.py validate <project-control.json>
python <skill-root>/scripts/project_control.py status <project-control.json> --output <records-directory>/status.md
python <skill-root>/scripts/project_control.py fingerprint <project-control.json>
```

Expected result: validation exits 0, status answers completion first, and fingerprint emits canonicalized content identity.

These commands prove local store behavior, structure, references, and declared-state consistency only. They do not verify source truth, authorization, delivery, acceptance, or benefit realization.
